import React from "react";

const Cek = () => {
  return (
    <>
      <div>Cek</div>
    </>
  );
};

export default Cek;
