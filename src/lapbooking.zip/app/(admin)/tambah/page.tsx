import { AddFieldForm } from "@/components/ui/addField";

export default function AddFieldPage() {
  return <AddFieldForm />;
}
