import React from "react";

const Kelola = () => {
  return (
    <>
      <div>Kelola</div>
    </>
  );
};

export default Kelola;
